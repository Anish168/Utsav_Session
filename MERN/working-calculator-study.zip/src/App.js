// import styles from "./app.module.css";
import "./styles.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Buttons from "./Components/Buttons";
import Display from "./Components/Display";
import { useState } from "react";
function App() {
  let [calVal, setCalVal] = useState("");
  function onButtonClick(buttonName) {
    // console.log(buttonName);
    if (buttonName === "C") {
      setCalVal("");
    } else if (buttonName === "=") {
      setCalVal(eval(calVal));
    } else {
      const newDisplay = calVal + buttonName;
      setCalVal(newDisplay);
    }
  }

  return (
    <div className="calculator">
      <Display displayValue={calVal}></Display>
      <div className="buttonContainer">
        <Buttons onButtonClick={onButtonClick}></Buttons>
      </div>
    </div>
  );
}

export default App;
