function Buttons({ onButtonClick }) {
  const buttonNames = [
    "C",
    "1",
    "2",
    "+",
    "3",
    "4",
    "-",
    "5",
    "6",
    "*",
    "7",
    "8",
    "/",
    "=",
    "9",
    "0",
    ".",
  ];
  return (
    <>
      {buttonNames.map((items) => (
        <button className="button" onClick={() => onButtonClick(items)}>
          {items}
        </button>
      ))}
    </>
  );
}
export default Buttons;
