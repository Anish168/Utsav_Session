function Display({ displayValue }) {
  return (
    <input
      className="display"
      type="text"
      readOnly
      value={displayValue}
    ></input>
  );
}
export default Display;
